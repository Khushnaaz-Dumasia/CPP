/*
 * ques2.cpp
 *
 *  Created on: 09-Aug-2023
 *      Author: root
 */
#include<iostream>
using namespace std;
class time{
public:
	int hours, minutes, seconds;
	//overloading == operator
	int operator ==(time t)
	{
		 if(hours == t.hours)
		 {
			 if(minutes == t.minutes)
			 {
				 if(seconds == t.seconds)
				 {
					 return 1;
				 }
			 }
		 }
		 return 0;
	}
	void operator >>(time t)//input
	{
		cout<<"\nEnter time: "<<endl;
		cin>>hours>>minutes>>seconds;
	}
	void operator <<(time t)//display
	{
		cout<<"\nTime entered is= "<<hours<<":"<<minutes<<":"<<seconds;
	}


}t1,t2;

//void time::input()
//{
//	cout<<"\nEnter time= ";
//	cin>>hours>>minutes>>seconds;
//}
//void time::display()
//{
//	cout<<"\nTime entered is= "<<hours<<":"<<minutes<<":"<<seconds;
//}

int main()
{
	t1.operator>>(t1);
	t1.operator<<(t1);
	//time t2;
	t2.operator>>(t2);
	t2.operator<<(t2);

	if(t1 == t2)
	{
		cout<<"\nBoth the values of time entered are equal";
	}
	else
	{
		cout<<"\nBoth the values of time entered are different";
	}
	return 0;
}
