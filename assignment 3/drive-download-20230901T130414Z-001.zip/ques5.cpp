/*
 * ques5.cpp
 *
 *  Created on: 17-Aug-2023
 *      Author: root
 */

#include<iostream>
using namespace std;
class binary{
public:
	float num;

	void operator >>(binary b)//input
	{
		cout<<"Enter a number= ";
		cin>>num;
	}
	void operator <<(binary b)//display
	{
		cout<<"\nNumber entered is: "<<num;
	}

	void operator +(binary b)
	{
		binary a;
		cout<<"\nSum of numbers = "<<a+b;
		//return c;
	}

	int operator -(binary b)
	{
		binary c, a;
		c=a-b;
		cout<<"\nDifference of numbers = "<<c;
		return c;
	}

	int operator *(binary b)
	{
		binary c, a;
		c=a*b;
		cout<<"\nProduct of numbers = "<<c;
		return c;
	}

	int operator /(binary b)
	{
		binary c, a;
		c=a/b;
		cout<<"\nDivision of numbers = "<<c;
		return c;
	}
}a,b,c;

int main()
{
	binary b1, b2, b3;
	int choice=0;
	{
		back:
		cout<<"\nEnter your choice: ";
		cin>>choice;
	}
	switch(choice)
	{
	//input
	case 1:
		b1.operator>>(b1);
		b2.operator>>(b2);
		goto back;
		break;

		//display
	case 2:
		b1.operator<<(b1);
		b2.operator<<(b2);
		goto back;
		break;

	case 3:
		b3=b1+b2;
		b3.operator<<;
		goto back;
		break;

	case 4:
		b3=b1-b2;
		b3.operator<<;
		goto back;
		break;

	case 5:
		b3=b1*b2;
		b3.operator<<;
		goto back;
		break;

	case 6:
		b3=b1/b2;
		b3.operator<<;
		goto back;
		break;

	case 7:
		cout<<"\nExited";
		exit(0);
		break;
	}
}


